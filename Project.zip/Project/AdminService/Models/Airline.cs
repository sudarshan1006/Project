﻿using System;
using System.Collections.Generic;

namespace AdminService.Models
{
    public partial class Airline
    {
        public Airline()
        {
            FlightDetails = new HashSet<FlightDetails>();
            PassangerDetails = new HashSet<PassangerDetails>();
        }

        public int AirlineId { get; set; }
        public int FlightNumber { get; set; }
        public string AirlineName { get; set; }
        public long? ContactNumber { get; set; }

        public ICollection<FlightDetails> FlightDetails { get; set; }
        public ICollection<PassangerDetails> PassangerDetails { get; set; }
    }
}
