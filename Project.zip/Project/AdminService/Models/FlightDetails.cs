﻿using System;
using System.Collections.Generic;

namespace AdminService.Models
{
    public partial class FlightDetails
    {
        public int FlightId { get; set; }
        public int? FlightNumber { get; set; }
        public string AirlineName { get; set; }
        public string FromPlace { get; set; }
        public string ToPlace { get; set; }
        public DateTime? StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public string SecheduledDays { get; set; }
        public int? BusinessClassSeats { get; set; }
        public int? NonBusinessClassSeats { get; set; }
        public double? TicketCost { get; set; }
        public int? NumberOfRows { get; set; }
        public string Meal { get; set; }
        public int? Deleted { get; set; }

        public Airline FlightNumberNavigation { get; set; }
    }
}
