﻿using AdminService.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminService.Repository
{
    public class AdminRepository: IAdminRepository

    {

        FlightBookingContext db;
        public AdminRepository(FlightBookingContext _db)
        {
            db = _db;
        }
        public async Task<int?> AddFlight(FlightDetails register)
        {
            if (db != null)
            {
                await db.FlightDetails.AddAsync(register);
                await db.SaveChangesAsync();

                return register.FlightNumber;
            }

            return 0;
        }
        public async Task<int?> Addairline(Airline airline)
        {
            if (db != null)
            {
                await db.Airline.AddAsync(airline);
                await db.SaveChangesAsync();

                return airline.FlightNumber;
            }

            return 0;
        }
        public async Task Block(int FlightNumber)
        {
            if (db != null)
            {
                var results = await db.FlightDetails.Where(reg => reg.FlightNumber == FlightNumber).FirstOrDefaultAsync();
                if (results.Deleted == 1)
                    results.Deleted = 0;
                else
                    results.Deleted = 1;
                
              db.FlightDetails.Update(results);
                await db.SaveChangesAsync();
           

            }
           
        } 
        public async Task<List<FlightDetails>> FlightDetails()
        {

            if (db != null)
            {
                return await db.FlightDetails.ToListAsync();
            }

            return null;
        }
        public async Task<List<Airline>> AirlineDetails()
        {

            if (db != null)
            {
                return await db.Airline.ToListAsync();
            }

            return null;
        }
        public async Task UpdateFlightData(FlightDetails reg)
        {
            if (db != null)
            {
                // that post
                db.FlightDetails.Update(reg);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
    }
}
