﻿using AdminService.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminService.Repository
{
   public  interface IAdminRepository
    {
        Task<int?> AddFlight(FlightDetails register);
        Task UpdateFlightData(FlightDetails reg);
        Task<List<FlightDetails>> FlightDetails();
        Task Block(int FlightNumber);
     
        Task<int?> Addairline(Airline airline);
        Task<List<Airline>> AirlineDetails();
    }
}
