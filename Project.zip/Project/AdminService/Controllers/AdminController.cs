﻿using AdminService.Models;
using AdminService.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AdminService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {

        IAdminRepository postRepository;
        public AdminController(IAdminRepository _postRepository)
        {
            postRepository = _postRepository;
        }

        [Route("/api/GetFlightDetails")]
        [HttpGet]

        public async Task<IActionResult> Get()
        {
            try
            {
                var userlist = await postRepository.FlightDetails();
                if (userlist == null)
                {
                    return NotFound();
                }

                return Ok(userlist);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }

        [Route("/api/GetAirline")]
        [HttpGet]

        public async Task<IActionResult> Getairline()
        {
            try
            {
                var userlist = await postRepository.AirlineDetails();
                if (userlist == null)
                {
                    return NotFound();
                }

                return Ok(userlist);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }

        [HttpGet]
        [Route("/api/BlockAirline/{FlightNumber}")]
        public async Task<IActionResult> BlockAirline(int FlightNumber)
        {

            try
            {
               await postRepository.Block(FlightNumber);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }
        [HttpPost]
        [Route("/api/AddFlight")]
        public async Task<IActionResult> AddFlight([FromBody] FlightDetails register)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var postId = await postRepository.AddFlight(register);
                    if (postId > 0)
                    {
                        return Ok(postId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }


            }
            return BadRequest();
        }
        [HttpPost]
        [Route("/api/Addairline")]
        public async Task<IActionResult> Addairline([FromBody] Airline airline)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var postId = await postRepository.Addairline(airline);
                    if (postId > 0)
                    {
                        return Ok(postId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }


            }
            return BadRequest();
        }
        [HttpPost]
        [Route("/api/UpdateFlightData")]
        public async Task<IActionResult> UpdateFlightDetails([FromBody] FlightDetails model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await postRepository.UpdateFlightData(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName ==
                             "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }

    }
}
