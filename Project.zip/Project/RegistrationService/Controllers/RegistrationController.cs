﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RegistrationService.Models;
using RegistrationService.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistrationService.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {

        IFlightBookingRepository postRepository;
        public RegistrationController(IFlightBookingRepository _postRepository)
        {
            postRepository = _postRepository;
        }

        [Route("/api/GetRegisteredUser")]
        [HttpGet]

        public async Task<IActionResult> Get()
        {
            try
            {
                var userlist = await postRepository.GetAllRegisteredUser();
                if (userlist == null)
                {
                    return NotFound();
                }

                return Ok(userlist);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }
        [Route("/api/Login/{Emailid}/{password}")]
        [HttpGet]
        public IActionResult Login(string EmailId, string password)
        {

            return Ok(postRepository.Login(EmailId, password));
         

    

        }

        [Route("/api/GetUserData/{Emailid}")]
        [HttpGet]
        public async Task<ActionResult<Registration>> GetRegistredUserById(string Emailid)
        {

            try
            {
                var post = await postRepository.GetData(Emailid);
                return post;
            }
            catch (Exception)
            {
                return null;
            }
        }
        [HttpPut]
        [Route("/api/UpdateData")]
        public async Task<IActionResult> UpdateUserData([FromBody] Registration model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await postRepository.UpdateData(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName ==
                             "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }

        [HttpPost]
        [Route("/api/AddUser")]
        public async Task<IActionResult> RegisterUser([FromBody] Registration register)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var postId = await postRepository.AddUser(register);
                    if (postId > 0)
                    {
                        return Ok(postId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception)
                {

                    return BadRequest();
                }


            }
            return BadRequest();
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
