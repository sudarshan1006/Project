﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RegistrationService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistrationService.Repository
{
    public class FlightBookingRepository: IFlightBookingRepository
    {

        FlightBookingContext db;
        public FlightBookingRepository(FlightBookingContext _db)
        {
            db = _db;
        }

        public async Task<int> AddUser(Registration register)
        {
            if (db != null)
            {
                await db.Registration.AddAsync(register);
                await db.SaveChangesAsync();

                return register.RegistrationId;
            }

            return 0;
        }

        public async Task<List<Registration>> GetAllRegisteredUser()
        {

            if (db != null)
            {
                return await db.Registration.ToListAsync();
            }

            return null;
        }
        public async Task<ActionResult<Registration>> GetData(string EmailId)
        {
            if (db != null)
            {
                var results = await db.Registration.Where(reg => reg.EmailId == EmailId).FirstOrDefaultAsync();

                //await db.Registration.AddAsync(results);
                //await db.SaveChangesAsync();

                return results;

            }
            return null;

        }
        public async Task UpdateData(Registration reg)
        {
            if (db != null)
            {
                // that post
                db.Registration.Update(reg);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
        public  bool Login(string emailid, string password)
        {

            if (db != null)
            {
                var result = db.Registration.Where(reg => reg.EmailId == emailid && reg.Password == password).FirstOrDefault();
                if (result != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;
        }

    }
}
