﻿using Microsoft.AspNetCore.Mvc;
using RegistrationService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistrationService.Repository
{
    public interface IFlightBookingRepository
    {

        //
        Task<List<Registration>> GetAllRegisteredUser();
        Task<int> AddUser(Registration register);
        Task<ActionResult<Registration>> GetData(string EmailId);
        Task UpdateData(Registration reg);

        //Task<List<PostViewModel>> GetPosts();
        bool Login(string emailid, string password);
    }
}
