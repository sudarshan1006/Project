﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;

namespace UserService.Repository
{
    public interface IUserRepository
    {
        //Task<List<FlightDetails>> Search(string From, string To, DateTime date);
        Task<long> BookTicket(int FlightNumber, string UseremailId, PassangerDetails passanger);
        Task<List<FlightDetails>> Search(string From, string To);
        Task<int> Cancel(int? pnr);
        Task<ActionResult<List<PassangerDetails>>> GetData(int Pnr);
        
        //Task<ActionResult<List<PassangerDetails>>> History(string EmailId);
    }
}
