﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;

namespace UserService.Repository
{
    public class UserRepository:IUserRepository
    {
        FlightBookingContext db;
        public UserRepository(FlightBookingContext _db)
        {
            db = _db;
        }
       
    public async Task<long> BookTicket(int FlightNumber, string UseremailId, PassangerDetails register)
        {
            if (db!=null)
            {
                var results = db.FlightDetails.Where(reg => reg.FlightNumber == FlightNumber).FirstOrDefault();
                register.FlightNumber = FlightNumber;
                register.BookingUserEmailId = UseremailId;
                if(register.CouponCode== "SPECIAL")
                {
                    register.Price = results.TicketCost-results.TicketCost * .10;
                }
                if (register.CouponCode == "NEW")
                {
                    register.Price = results.TicketCost -results.TicketCost * .15;
                }
                if (register.CouponCode == "JUMBO")
                {
                    register.Price = results.TicketCost-results.TicketCost * .20;
                }
               



                await db.PassangerDetails.AddAsync(register);
                await db.SaveChangesAsync();
                return register.Pnr;
            } 

            

            return 0;
        }
        public async Task<ActionResult<List<PassangerDetails>>> GetData(int Pnr)
        {
            if (db != null)
            {
                var results = await db.PassangerDetails.Where(reg => reg.Pnr == Pnr).ToListAsync();

                //await db.Registration.AddAsync(results);
                //await db.SaveChangesAsync();

                return results;

            }
            return null;

        }
        //public async Task<ActionResult<List<PassangerDetails>>> History(string EmailId)
        //{
        //    if (db != null)
        //    {
        //        var  passangerlist = new PassangerDetails[1000];
        //        var results = await db.BookingDetails.Where(reg => reg.BookingUserEmailId == EmailId).ToListAsync();
        //        foreach (var data in results )
        //        {
        //           var info= await db.PassangerDetails.Where(reg => reg.Pnr == data.Pnr).ToListAsync();


        //        }
        //        //await db.Registration.AddAsync(results);
        //        //await db.SaveChangesAsync();

        //        return results;

        //    }
        //    return null;

        //}
        //public async Task<List<BookingDetails>> GetBookingInfo()
        //{
            
        //}
    

        public async Task<List<FlightDetails>> Search(string From, string To)
        {

            if (db != null)
            {
               return await db.FlightDetails.Where(reg => reg.FromPlace == From && reg.ToPlace == To && reg.Deleted==0).ToListAsync();
               
            }

            return null;
        }
        public async Task<int> Cancel(int? pnr)
        {
            int result = 0;

            if (db != null)
            {
                //Find the post for specific post id

                var data2 = await db.PassangerDetails.Where(reg => reg.Pnr==pnr).ToListAsync();
                if (data2!=null)
                {
                    result = 1;
                    foreach(var info in data2)
                    {
                        db.PassangerDetails.Remove(info);
                        await db.SaveChangesAsync();
                    }
                }
                
                return result;
            }

            return result;
        }
    }
}
