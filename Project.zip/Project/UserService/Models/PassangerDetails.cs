﻿using System;
using System.Collections.Generic;

namespace UserService.Models
{
    public partial class PassangerDetails
    {
        public long Pnr { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
        public string Gender { get; set; }
        public int? BusinessClassSeats { get; set; }
        public int? NonBusinessClassSeats { get; set; }
        public double? Price { get; set; }
        public string BookingUserEmailId { get; set; }
        public string CouponCode { get; set; }
        public DateTime? BookingDate { get; set; }
        public int? FlightNumber { get; set; }

        public Airline FlightNumberNavigation { get; set; }
    }
}
