﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace UserService.Models
{
    public partial class FlightBookingContext : DbContext
    {
        public FlightBookingContext()
        {
        }

        public FlightBookingContext(DbContextOptions<FlightBookingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Airline> Airline { get; set; }
        public virtual DbSet<FlightDetails> FlightDetails { get; set; }
        public virtual DbSet<PassangerDetails> PassangerDetails { get; set; }
        public virtual DbSet<Registration> Registration { get; set; }

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("Server=CTSDOTNET53;Database=FlightBooking;UID=sa;PWD=pass@word1;");
//            }
//        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Airline>(entity =>
            {
                entity.HasKey(e => e.FlightNumber);

                entity.Property(e => e.FlightNumber).ValueGeneratedNever();

                entity.Property(e => e.AirlineId).ValueGeneratedOnAdd();

                entity.Property(e => e.AirlineName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<FlightDetails>(entity =>
            {
                entity.HasKey(e => e.FlightId);

                entity.Property(e => e.AirlineName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Deleted).HasColumnName("deleted");

                entity.Property(e => e.EndDateTime).HasColumnType("datetime");

                entity.Property(e => e.FromPlace)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Meal)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SecheduledDays)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.StartDateTime).HasColumnType("datetime");

                entity.Property(e => e.ToPlace)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.HasOne(d => d.FlightNumberNavigation)
                    .WithMany(p => p.FlightDetails)
                    .HasForeignKey(d => d.FlightNumber)
                    .HasConstraintName("FK__FlightDet__Fligh__7C4F7684");
            });

            modelBuilder.Entity<PassangerDetails>(entity =>
            {
                entity.HasKey(e => e.Pnr);

                entity.Property(e => e.Pnr).HasColumnName("PNR");

                entity.Property(e => e.BookingDate).HasColumnType("datetime");

                entity.Property(e => e.BookingUserEmailId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.CouponCode)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.FlightNumberNavigation)
                    .WithMany(p => p.PassangerDetails)
                    .HasForeignKey(d => d.FlightNumber)
                    .HasConstraintName("FK__Passanger__Fligh__7F2BE32F");
            });

            modelBuilder.Entity<Registration>(entity =>
            {
                entity.Property(e => e.EmailId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityQstn1)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityQstn2)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });
        }
    }
}
