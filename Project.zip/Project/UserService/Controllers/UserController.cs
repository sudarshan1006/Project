﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;
using UserService.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace UserService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IUserRepository postRepository;
        public UserController(IUserRepository _postRepository)
        {
            postRepository = _postRepository;
        }
        [Route("/api/BookTicket/{Emailid}/{FlightNumber}")]
        [HttpPost]
        public async Task<long> BookTicket(string Emailid,int FlightNumber, [FromBody] PassangerDetails model)
        {

            try
            {
                var post = await postRepository.BookTicket(FlightNumber, Emailid, model);
                return post;
            }
            catch (Exception)
            {
                return 0;
            }
        }
       

        // GET: api/<UserController>
        [HttpGet]
        [Route("/api/Search/{From}/{To}")]
        public async Task<IActionResult> Search(string From, string To, DateTime date)
        {
            try
            {
                var userlist = await postRepository.Search(From, To);
                if (userlist == null)
                {
                    return NotFound();
                }

                return Ok(userlist);
            }
            catch (Exception)
            {
                return BadRequest();
            }

        }
        [HttpGet]
        [Route("/api/PNR/{Pnr}")]
        public async Task<ActionResult<List<PassangerDetails>>> GetBookedTicketDetails(int  Pnr)
        {

            try
            {
                var post = await postRepository.GetData(Pnr);
                return post;
            }
            catch (Exception)
            {
                return null;
            }
        }
        //[HttpGet]
        //[Route("/api/History/{EmailId}")]
        //public async Task<ActionResult<List<PassangerDetails>>> History(string EmailId)
        //{

        //    try
        //    {
        //        var post = await postRepository.History(EmailId);
        //        return post;
        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //}
        // DELETE api/<UserController>/5

        [HttpGet]
        [Route("/api/Cancel/{Pnr}")]
        public async Task<IActionResult> CancelFlightTicket(int Pnr)
        {
            int result = 0;

            if (Pnr == 0)
            {
                return BadRequest();
            }

            try
            {
                result = await postRepository.Cancel(Pnr);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return Ok();
            }
        }
    }
}
